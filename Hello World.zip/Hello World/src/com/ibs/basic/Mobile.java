package com.ibs.basic;

class Base{
public Base() {

}
public Base(int a) {
System.out.println(20);
}
}
class Sub extends Base{
public Sub() {
this(10);
System.out.println(30);
}
public Sub(int a) {
System.out.println(40);
}
}
class Mobile extends Sub{
public  Mobile() {
super(10);
System.out.println(50);
}
}
