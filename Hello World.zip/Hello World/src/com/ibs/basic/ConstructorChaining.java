package com.ibs.basic;

public class ConstructorChaining {
public static void main(String[] args) {
	 Sub subChild = new  Sub();
}
}