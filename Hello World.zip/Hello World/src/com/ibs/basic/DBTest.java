package com.ibs.basic;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DBTest {
	public static void main(String[] args) {
		try {
			Class.forName("org.postgresql.Driver");
			Connection con = 
					DriverManager.getConnection("jdbc:postgresql://localhost:5432/Employee","postgres", "233023");
Statement stmt = con.createStatement();
			
System.out.println("List of Employees who have salary greater than 25000: ");
	         ResultSet rs1 = stmt.executeQuery("select EMPNAME from empltable where Salary>25000");
while(rs1.next()) {
	        	 
System.out.println(rs1.getString("EMPNAME"));
}
			
String sql1 = "UPDATE empltable SET Job='Senior Software Engineer' WHERE Job='Software Engineer'";
stmt.executeUpdate(sql1);
System.out.println("Updated the job of software Engineer as Senior Software Engineer \n");

String sql2 = "INSERT INTO empltable VALUES ('A-10358', 'MARCO', '10-09-21',27000,'8-oct-11','Test Engineer')";
stmt.executeUpdate(sql2);
System.out.println("Inserted a new Record into table \n ");	 
 
String sql4= "DELETE FROM empltable WHERE Job='Project Manager' and Salary>1000";
stmt.executeUpdate(sql4);
System.out.println("Deleted a record whose job is Project Manager and salary is greater than 1000 \n");

String sql5 = "UPDATE empltable SET Hiredate='10-sep-2018' WHERE EMPNAME='Anna' or EMPNAME='Peter'";
stmt.executeUpdate(sql5);
System.out.println("Updated the hiredate of employees Peter & Anna as 10-Sep-2018 \n");


ResultSet rs = stmt.executeQuery("select * from empltable");
System.out.println("***********************Final Table**************************************");
while(rs.next()) {
	        	 
System.out.println(rs.getString("EMPNO")+" :: "+rs.getString("EMPNAME")+ " :: "+rs.getString("DOB")+ " :: "+rs.getString("Salary")+ " :: "+rs.getString("Hiredate")+ " :: "+rs.getString("Job"));
}
			
} catch (ClassNotFoundException e) {
System.out.println("Driver class not found");
} catch (SQLException e) {
System.out.println("SQL Exception occured");
}
	}

}

